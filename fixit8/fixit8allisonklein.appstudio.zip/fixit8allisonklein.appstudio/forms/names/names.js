// FOR LOOPS

var names = ['Bob', ' Janet', ' Tom', ' Bob', ' Randy', ' Elizabeth', ' Kim', ' Nancy'];
/* alert(`Prior to the loop, we begin with ${names}.`) DIDN'T INCLUDE BY DEFAULT --> displays entire array before shrinking to 4 outputs */

for (let i = 0; i < names.length - 4; i++)
alert(names[i]);