// WHILE LOOPS

var userNumber = prompt("Enter a number between 1 and 10.");
         
while (userNumber <= 10) {
  alert("This is loop iteration " + userNumber);
  userNumber++;
}

alert("The loop is now done.");